using Microsoft.EntityFrameworkCore;
using KAVEH.AggregateLedger.Web.Data;

namespace KAVEH.AggregateLedger.Web
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddRazorPages();
            builder.Services.AddDbContext<AppDbContext>(opts =>
                opts.UseSqlite(builder.Configuration.GetConnectionString("DefaultConnection") ?? "Data Source=Data/app.db"));

            var app = builder.Build();

            var dataDir = Path.Combine(app.Environment.ContentRootPath, "Data");
            Directory.CreateDirectory(dataDir);
            using (var scope = app.Services.CreateScope())
            {
                var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
                db.Database.EnsureCreated();
            }

            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseRouting();
            app.MapRazorPages();
            app.Run();
        }
    }
}
