
// ===== Persian digits & money formatting (robust) =====
(function(){
  const fa = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
  const en = ['0','1','2','3','4','5','6','7','8','9'];
  function toFa(str){ return String(str).replace(/\d/g, d => fa[+d]); }
  function toEn(str){ return String(str).replace(/[۰-۹]/g, d => en[fa.indexOf(d)]); }
  function cleanNum(str){ return toEn(String(str)).replace(/[,٬\s]/g,''); } // remove comma and Arabic thousands (U+066C)

  function moneyFaFromRaw(raw){
    const cleaned = cleanNum(raw);
    const n = Number(cleaned);
    if (Number.isFinite(n)) {
      try { return new Intl.NumberFormat('fa-IR').format(n); } catch(e){ return toFa(cleaned); }
    }
    return raw; // leave as-is if not a number
  }

  function formatPage(){
    document.querySelectorAll('.money-fa').forEach(el => {
      const raw = el.getAttribute('data-amount') ?? el.textContent;
      el.textContent = moneyFaFromRaw(raw);
    });
    document.querySelectorAll('.fa-number').forEach(el => { el.textContent = toFa(el.textContent); });
  }
  document.addEventListener('DOMContentLoaded', formatPage);

  // Convert inputs with .en-on-submit to English digits and strip separators before submit
  document.addEventListener('submit', function(e){
    const form = e.target;
    form.querySelectorAll('.en-on-submit').forEach(inp => { inp.value = cleanNum(inp.value); });
  }, true);

  window.__fa = { toFa, toEn, moneyFaFromRaw };
})();


// ===== Sidebar minimize / restore with persistence =====
document.addEventListener('DOMContentLoaded', function(){
  try {
    var key='__sidebar_mini__';
    var btn=document.getElementById('sidebarToggleMini');
    if(localStorage.getItem(key)==='1'){ document.body.classList.add('sidebar-mini'); }
    btn && btn.addEventListener('click', function(e){
      e.preventDefault();
      document.body.classList.toggle('sidebar-mini');
      localStorage.setItem(key, document.body.classList.contains('sidebar-mini') ? '1':'0');
    });
  } catch(e){}
});

// ===== Sidebar hide/show toggle with persistence =====
document.addEventListener('DOMContentLoaded', function(){
  var keyHS='__sidebar_hidden__';
  try {
    if(localStorage.getItem(keyHS)==='1'){ document.body.classList.add('sidebar-hidden'); }
    var btnHide=document.getElementById('sidebarToggleHide');
    if(btnHide){
      btnHide.addEventListener('click', function(e){
        e.preventDefault();
        document.body.classList.toggle('sidebar-hidden');
        localStorage.setItem(keyHS, document.body.classList.contains('sidebar-hidden')?'1':'0');
      });
    }
  } catch(e){}
});

try{ document.body.classList.remove('sidebar-hidden','sidebar-show','sidebar-mini'); }catch(e){}

try{ document.body.classList.remove('sidebar-hidden','sidebar-show','sidebar-mini'); }catch(e){}
