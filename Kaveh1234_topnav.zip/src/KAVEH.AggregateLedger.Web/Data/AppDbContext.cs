using Microsoft.EntityFrameworkCore;
using KAVEH.AggregateLedger.Web.Models;

namespace KAVEH.AggregateLedger.Web.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) {}
    public DbSet<Transaction> Transactions => Set<Transaction>();
    public DbSet<Bank> Banks => Set<Bank>();
    public DbSet<Purpose> Purposes => Set<Purpose>();
    public DbSet<CompanyInfo> CompanyInfos => Set<CompanyInfo>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Bank>().HasData(new Bank{Id=1,Name="بانک ملی",Active=true}, new Bank{Id=2,Name="بانک ملت",Active=true});
        modelBuilder.Entity<Purpose>().HasData(new Purpose{Id=1,Name="فروش روزانه",Active=true}, new Purpose{Id=2,Name="هزینه",Active=true});
        modelBuilder.Entity<CompanyInfo>().HasData(new CompanyInfo{Id=1, Name="شرکت شن و ماسه", Address="استان/شهر، آدرس کامل", Phone="021-00000000"});
    }
}
