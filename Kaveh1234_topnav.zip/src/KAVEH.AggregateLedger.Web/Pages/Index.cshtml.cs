using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using KAVEH.AggregateLedger.Web.Data;
using KAVEH.AggregateLedger.Web.Models;
using System.Globalization;

namespace KAVEH.AggregateLedger.Web.Pages;

public class IndexModel : PageModel
{
    private readonly AppDbContext _db;
    public IndexModel(AppDbContext db){ _db = db; }

    [BindProperty(SupportsGet=true, Name="date")]
    public string? DateQuery { get; set; }
    public DateOnly Date { get; set; }
    public List<Transaction> Items { get; set; } = new();
    public List<Bank> Banks { get; set; } = new();
    public List<Purpose> Purposes { get; set; } = new();

    [BindProperty] public InputModel Input { get; set; } = new();

    public class InputModel
    {
        public int PYear { get; set; }
        public int PMonth { get; set; }
        public int PDay { get; set; }
        public decimal Amount { get; set; }
        public TxnType Type { get; set; } = TxnType.debit;
        public int? BankId { get; set; }
        public int? PurposeId { get; set; }
        public string? Description { get; set; }
    }

    public async Task OnGetAsync()
    {
        Date = ParseDate(DateQuery) ?? DateOnly.FromDateTime(DateTime.Now);
        var pc = new PersianCalendar();
        var dt = Date.ToDateTime(TimeOnly.MinValue);
        Input.PYear = pc.GetYear(dt); Input.PMonth = pc.GetMonth(dt); Input.PDay = pc.GetDayOfMonth(dt);
        Items = await _db.Transactions.Include(x=>x.Bank).Include(x=>x.Purpose).Where(t=>t.Date==Date).OrderByDescending(t=>t.Id).ToListAsync();
        Banks = await _db.Banks.Where(b=>b.Active).OrderBy(b=>b.Name).ToListAsync();
        Purposes = await _db.Purposes.Where(p=>p.Active).OrderBy(p=>p.Name).ToListAsync();
    }

    public async Task<IActionResult> OnPostAsync()
    {
        var date = FromPersian(Input.PYear, Input.PMonth, Input.PDay);
        var tx = new Transaction { Date = date, Amount = Input.Amount, Type = Input.Type, BankId = Input.BankId, PurposeId = Input.PurposeId, Description = Input.Description };
        _db.Transactions.Add(tx);
        await _db.SaveChangesAsync();
        return RedirectToPage("/Index", new { date = date.ToString("yyyy-MM-dd") });
    }

    private static DateOnly FromPersian(int y,int m,int d){
        var pc=new PersianCalendar();
        d = Math.Clamp(d,1, pc.GetDaysInMonth(y, Math.Clamp(m,1,12)));
        return DateOnly.FromDateTime(new DateTime(y, Math.Clamp(m,1,12), d, pc));
    }
    private static DateOnly? ParseDate(string? s){
        if (string.IsNullOrWhiteSpace(s)) return null;
        var parts = s.Split('-', '/');
        if (parts.Length>=3 && int.TryParse(parts[0],out int y) && int.TryParse(parts[1],out int m) && int.TryParse(parts[2],out int d)){
            if (y>=1300 && y<=1600) return FromPersian(y,m,d);
            if (DateOnly.TryParseExact($"{y:0000}-{m:00}-{d:00}","yyyy-MM-dd",CultureInfo.InvariantCulture,System.Globalization.DateTimeStyles.None,out var g)) return g;
        }
        return null;
    }
}
