using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using KAVEH.AggregateLedger.Web.Data;
using KAVEH.AggregateLedger.Web.Models;
using System.Globalization;

namespace KAVEH.AggregateLedger.Web.Pages.Report;

public class MonthlyModel : PageModel
{
    private readonly AppDbContext _db;
    public MonthlyModel(AppDbContext db){ _db = db; }

    public int Year { get; set; }
    public int Month { get; set; }
    public DateOnly Start { get; set; }
    public DateOnly End { get; set; }
    public decimal TotalDebit { get; set; }
    public decimal TotalCredit { get; set; }
    public List<Transaction> All { get; set; } = new();
    public List<(string? Purpose, int Count, decimal Sum)> PurposesAgg { get; set; } = new();
    public List<GroupRow> TotalsByPurpose { get; set; } = new();
    public record GroupRow(string? Key, decimal Sum);

    public async Task OnGetAsync(string? pmonth)
    {
        var pc=new PersianCalendar();
        int y, m;
        if (!TryParsePM(pmonth, out y, out m)){ var now=DateTime.Now; y=pc.GetYear(now); m=pc.GetMonth(now); }
        Year=y; Month=m;
        var days=pc.GetDaysInMonth(y,m);
        Start = DateOnly.FromDateTime(new DateTime(y,m,1,pc));
        End = DateOnly.FromDateTime(new DateTime(y,m,days,pc));
        All = await _db.Transactions.Include(x=>x.Bank).Include(x=>x.Purpose).Where(t=>t.Date>=Start && t.Date<=End).OrderBy(t=>t.Date).ThenBy(t=>t.Id).ToListAsync();
        TotalDebit = All.Where(t=>t.Type==TxnType.debit).Sum(t=>t.Amount);
        TotalCredit = All.Where(t=>t.Type==TxnType.credit).Sum(t=>t.Amount);
        PurposesAgg = All.Where(t=>t.PurposeId!=null)
            .GroupBy(t=>t.Purpose!.Name)
            .Select(g => (Purpose: g.Key, Count: g.Count(), Sum: g.Sum(x=>x.Amount)))
            .OrderByDescending(x=>x.Sum).ToList();
        TotalsByPurpose = All.GroupBy(t=>t.Purpose?.Name)
            .Select(g=> new GroupRow(g.Key??"-", g.Sum(x=>x.Amount))).OrderByDescending(g=>g.Sum).ToList();
    }

    private static bool TryParsePM(string? s, out int y, out int m){
        y=0;m=0; if (string.IsNullOrWhiteSpace(s)) return false; var p=s.Split('-', '/', '_'); if (p.Length<2) return false; return int.TryParse(p[0],out y) && int.TryParse(p[1],out m) && m>=1 && m<=12;
    }
}
