using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using KAVEH.AggregateLedger.Web.Data;
using KAVEH.AggregateLedger.Web.Models;
using System.Globalization;

namespace KAVEH.AggregateLedger.Web.Pages.Report;

public class PrintDailyModel : PageModel
{
    private readonly AppDbContext _db;
    public PrintDailyModel(AppDbContext db){ _db = db; }
    public DateOnly Date { get; set; }
    public List<Transaction> All { get; set; } = new();
    public decimal DebitSum { get; set; }
    public decimal CreditSum { get; set; }

    public async Task OnGetAsync(string? date)
    {
        Date = Parse(date) ?? DateOnly.FromDateTime(DateTime.Now);
        All = await _db.Transactions.Include(x=>x.Bank).Include(x=>x.Purpose).Where(t=>t.Date==Date).OrderBy(t=>t.Id).ToListAsync();
        DebitSum = All.Where(t=>t.Type==TxnType.debit).Sum(t=>t.Amount);
        CreditSum = All.Where(t=>t.Type==TxnType.credit).Sum(t=>t.Amount);
    }
    private static DateOnly? Parse(string? s){
        if (string.IsNullOrWhiteSpace(s)) return null;
        var parts=s.Split('-','/'); if (parts.Length<3) return null;
        int y=int.Parse(parts[0]),m=int.Parse(parts[1]),d=int.Parse(parts[2]);
        if (y>=1300) { var pc=new PersianCalendar(); d=Math.Clamp(d,1,pc.GetDaysInMonth(y,Math.Clamp(m,1,12))); return DateOnly.FromDateTime(new DateTime(y,m,d,pc)); }
        return DateOnly.Parse($"{y:0000}-{m:00}-{d:00}");
    }
}
