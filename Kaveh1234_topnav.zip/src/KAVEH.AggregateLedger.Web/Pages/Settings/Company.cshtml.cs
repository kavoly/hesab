using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using KAVEH.AggregateLedger.Web.Data;
using KAVEH.AggregateLedger.Web.Models;

namespace KAVEH.AggregateLedger.Web.Pages.Settings;

public class CompanyModel : PageModel
{
    private readonly AppDbContext _db;
    public CompanyModel(AppDbContext db){ _db=db; }
    [BindProperty] public CompanyInfo Input { get; set; } = new();

    public async Task OnGetAsync(){ Input = await _db.CompanyInfos.FirstOrDefaultAsync() ?? new CompanyInfo{Id=1}; }
    public async Task<IActionResult> OnPostAsync(){
        var e = await _db.CompanyInfos.FirstOrDefaultAsync();
        if (e==null) _db.CompanyInfos.Add(Input);
        else { e.Name=Input.Name; e.Address=Input.Address; e.Phone=Input.Phone; }
        await _db.SaveChangesAsync();
        return RedirectToPage();
    }
}
