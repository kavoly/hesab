using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using KAVEH.AggregateLedger.Web.Data;
using KAVEH.AggregateLedger.Web.Models;

namespace KAVEH.AggregateLedger.Web.Pages.Settings;

public class ListsModel : PageModel
{
    private readonly AppDbContext _db;
    public ListsModel(AppDbContext db){ _db=db; }
    public List<Bank> Banks { get; set; } = new();
    public List<Purpose> Purposes { get; set; } = new();
    [BindProperty] public string? BankName { get; set; }
    [BindProperty] public string? PurposeName { get; set; }

    public async Task OnGetAsync(){ Banks=await _db.Banks.OrderBy(x=>x.Name).ToListAsync(); Purposes=await _db.Purposes.OrderBy(x=>x.Name).ToListAsync(); }
    public async Task<IActionResult> OnPostAddBankAsync(){ if(!string.IsNullOrWhiteSpace(BankName)) _db.Banks.Add(new Bank{Name=BankName,Active=true}); await _db.SaveChangesAsync(); return RedirectToPage(); }
    public async Task<IActionResult> OnPostToggleBankAsync(int id){ var b=await _db.Banks.FindAsync(id); if(b!=null){ b.Active=!b.Active; await _db.SaveChangesAsync(); } return RedirectToPage(); }
    public async Task<IActionResult> OnPostAddPurposeAsync(){ if(!string.IsNullOrWhiteSpace(PurposeName)) _db.Purposes.Add(new Purpose{Name=PurposeName,Active=true}); await _db.SaveChangesAsync(); return RedirectToPage(); }
    public async Task<IActionResult> OnPostTogglePurposeAsync(int id){ var p=await _db.Purposes.FindAsync(id); if(p!=null){ p.Active=!p.Active; await _db.SaveChangesAsync(); } return RedirectToPage(); }
}
