
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Rendering;
using KAVEH.AggregateLedger.Web.Data;
using KAVEH.AggregateLedger.Web.Models;

namespace KAVEH.AggregateLedger.Web.Pages.Transactions;

public class EditModel : PageModel
{
    private readonly AppDbContext _db;
    public EditModel(AppDbContext db){ _db=db; }

    [BindProperty] public Transaction? Item { get; set; }

    public SelectList TxnTypes { get; set; } = null!;
    public SelectList BankList { get; set; } = null!;
    public SelectList PurposeList { get; set; } = null!;

    public async Task<IActionResult> OnGetAsync(int id)
    {
        Item = await _db.Transactions.FindAsync(id);
        if (Item==null) return NotFound();
        await LoadSelectsAsync();
        return Page();
    }

    public async Task<IActionResult> OnPostAsync()
    {
        if (Item==null) return NotFound();
        var entity = await _db.Transactions.FindAsync(Item.Id);
        if (entity==null) return NotFound();

        entity.Amount = Item.Amount;
        entity.Type = Item.Type;
        entity.BankId = Item.BankId;
        entity.PurposeId = Item.PurposeId;
        entity.Description = Item.Description;
        await _db.SaveChangesAsync();
        return RedirectToPage("/Index", new { date = entity.Date.ToString("yyyy-MM-dd") });
    }

    private async Task LoadSelectsAsync()
    {
        TxnTypes = new SelectList(new[] {
            new { Value = TxnType.debit, Text = "بدهکار" },
            new { Value = TxnType.credit, Text = "بستانکار" }
        }, "Value", "Text", Item?.Type);

        var banks = await _db.Banks.Where(b=>b.Active).OrderBy(b=>b.Name).ToListAsync();
        BankList = new SelectList(banks, "Id", "Name", Item?.BankId);

        var purposes = await _db.Purposes.Where(p=>p.Active).OrderBy(p=>p.Name).ToListAsync();
        PurposeList = new SelectList(purposes, "Id", "Name", Item?.PurposeId);
    }
}
