namespace KAVEH.AggregateLedger.Web.Models;

public enum TxnType { debit, credit }

public class Transaction
{
    public int Id { get; set; }
    public DateOnly Date { get; set; }
    public decimal Amount { get; set; }
    public TxnType Type { get; set; } = TxnType.debit;
    public int? BankId { get; set; }
    public Bank? Bank { get; set; }
    public int? PurposeId { get; set; }
    public Purpose? Purpose { get; set; }
    public string? Description { get; set; }
}

public class Bank { public int Id { get; set; } public string Name { get; set; } = ""; public bool Active { get; set; } = true; }
public class Purpose { public int Id { get; set; } public string Name { get; set; } = ""; public bool Active { get; set; } = true; }
public class CompanyInfo { public int Id { get; set; } = 1; public string? Name { get; set; } public string? Address { get; set; } public string? Phone { get; set; } }
