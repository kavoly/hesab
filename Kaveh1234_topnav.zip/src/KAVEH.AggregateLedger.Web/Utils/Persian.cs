using System.Globalization;
using PersianDate;

namespace KAVEH.AggregateLedger.Web;

public static class Persian
{
    private static readonly PersianCalendar Pc = new();
    public static string Digits(string input) => input
        .Replace('0','۰').Replace('1','۱').Replace('2','۲').Replace('3','۳').Replace('4','۴')
        .Replace('5','۵').Replace('6','۶').Replace('7','۷').Replace('8','۸').Replace('9','۹');

    public static string Money(decimal value) => Digits(string.Format(CultureInfo.GetCultureInfo("fa-IR"), "{0:N0}", value));

    public static string ToPersianDate(DateOnly date)
    {
        var dt = date.ToDateTime(TimeOnly.MinValue);
        int y = Pc.GetYear(dt); int m = Pc.GetMonth(dt); int d = Pc.GetDayOfMonth(dt);
        return $"{Digits(y.ToString("0000"))}/{Digits(m.ToString("00"))}/{Digits(d.ToString("00"))}";
    }

    public static (DateOnly start, DateOnly end, int days) PersianMonthRange(int py, int pm)
    {
        int days = Pc.GetDaysInMonth(py, pm);
        var s = new DateTime(py, pm, 1, Pc);
        var e = new DateTime(py, pm, days, Pc);
        return (DateOnly.FromDateTime(s), DateOnly.FromDateTime(e), days);
    }
}
